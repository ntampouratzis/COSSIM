This directory will contain RTI independant source code
which may help to develop HLA Federate 

see
https://savannah.nongnu.org/patch/?6534
https://savannah.nongnu.org/task/?8386
http://lists.nongnu.org/archive/html/certi-devel/2008-07/msg00027.html
