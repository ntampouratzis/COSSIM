#ifndef SHARED_STRUCT_H
#define SHARED_STRUCT_H

/* For FILE */
#include <stdio.h>

typedef struct {
    int Header;
    double Body;
} shared_struct ;

#endif


