The file in there are xml related files coming from the IEEE-1516 norms.

ieee1516-2000/1516_2-2000/
   Contains IEEE-1516 version 2000 related files.
   The files comes from:
   http://www.sisostds.org/DigitalLibrary.aspx?Command=Core_Download&EntryId=29251
   http://www.sisostds.org/DigitalLibrary.aspx?EntryId=29241

ieee1516-2010/1516_[12]-2010/
   Contains IEEE-1516 version 2010 related files.
   The files comes from:
   http://standards.ieee.org/downloads/1516/ 

