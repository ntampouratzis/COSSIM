#ifndef WITH_TCP_COMMON
#define WITH_TCP_COMMON
#endif

#ifndef WITH_TCP_INET
#define WITH_TCP_INET
#endif

#ifndef WITH_IPv4
#define WITH_IPv4
#endif

#ifndef WITH_IPv6
#define WITH_IPv6
#endif

#ifndef WITH_xMIPv6
#define WITH_xMIPv6
#endif

#ifndef WITH_GENERIC
#define WITH_GENERIC
#endif

#ifndef WITH_FLOOD
#define WITH_FLOOD
#endif

#ifndef WITH_UDP
#define WITH_UDP
#endif

#ifndef WITH_RTP
#define WITH_RTP
#endif

#ifndef WITH_SCTP
#define WITH_SCTP
#endif

#ifndef WITH_DHCP
#define WITH_DHCP
#endif

#ifndef WITH_ETHERNET
#define WITH_ETHERNET
#endif

#ifndef WITH_PPP
#define WITH_PPP
#endif

#ifndef WITH_MPLS
#define WITH_MPLS
#endif

#ifndef WITH_OSPFv2
#define WITH_OSPFv2
#endif

#ifndef WITH_BGPv4
#define WITH_BGPv4
#endif

#ifndef WITH_PIM
#define WITH_PIM
#endif

#ifndef WITH_AODV
#define WITH_AODV
#endif

#ifndef WITH_RIP
#define WITH_RIP
#endif

#ifndef WITH_POWER
#define WITH_POWER
#endif

#ifndef WITH_RADIO
#define WITH_RADIO
#endif

#ifndef WITH_IEEE80211
#define WITH_IEEE80211
#endif

#ifndef WITH_IEEE802154
#define WITH_IEEE802154
#endif

#ifndef WITH_APSKRADIO
#define WITH_APSKRADIO
#endif

#ifndef WITH_IDEALWIRELESS
#define WITH_IDEALWIRELESS
#endif

#ifndef WITH_TUN
#define WITH_TUN
#endif

#ifndef WITH_PACKETDRILL
#define WITH_PACKETDRILL
#endif

#ifndef WITH_BMAC
#define WITH_BMAC
#endif

#ifndef WITH_LMAC
#define WITH_LMAC
#endif

#ifndef WITH_CSMA
#define WITH_CSMA
#endif

